# Exercise

We have a sample web-page.

![Untitled](Exercise%205940e9ab5e3549bb829dbb17bacc7729/Untitled.png)

Here are the respective HTML & CSS files for this web-page.

![Untitled](Exercise%205940e9ab5e3549bb829dbb17bacc7729/Untitled%201.png)

![Untitled](Exercise%205940e9ab5e3549bb829dbb17bacc7729/Untitled%202.png)

(**NOTE:** You have to find the images used in this webpage yourself. You can use whatever appropriate images you like.)

But currently there are some inconsistencies within this page, we have to fix it by manipulating the HTML & CSS using JS.

Let’s fix it one by one.

- The image icons for CSS & JS list items are the same as HTML currently. Set the image of CSS & JS items to their respective icons using `setAttribute()` but before setting the image first ensure that you are setting the correct icon for the matching image element. (for e.g. check if the `alt` of an image is `CSS-icon` then only set css icon image for it.)
    
    [**HINT:** Use `getAttribute()` to first know what is the value of `alt` for the image element you are about to set the image for]
    
- The CSS & JS list items don’t have the styling similar to HTML one. Add the class applied to HTML for CSS & JS list items as well.
- Main-Topics of Front-end Web Development heading looks dull at the moment. Apply the `topic-heading` class to it for the styling.
- “Let’s Learn!” heading has a similar styling to the above heading, remove styling related class from it.
- Apply the button related styling (`btn` class) to Enroll button.
- Take a user input saying "Write 'yes' if you want to enroll, otherwise 'no'”.  Now if the user says ‘no’ then toggle `btn-inactive` class for the enroll button and `btn-active` if user says ‘yes’.

[Answer](https://www.notion.so/Answer-20725c56e8154b2c8d1d9e39e50c0c29?pvs=21)